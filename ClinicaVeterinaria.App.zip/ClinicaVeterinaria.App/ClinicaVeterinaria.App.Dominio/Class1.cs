﻿using System;

namespace ClinicaVeterinaria.App.Dominio
{
    public class Class1
    {
    }
}
