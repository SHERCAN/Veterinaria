﻿using System;

namespace ClinicaVeterinaria.App.Persistencia
{
    public class Class1
    {
    }
}
